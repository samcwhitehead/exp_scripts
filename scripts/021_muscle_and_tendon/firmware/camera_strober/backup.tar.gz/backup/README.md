##  camera_strober

Arduino firmware and Python library for controlling camera during muscle imaging. 

## Firmware

* Location: "firmware" sub-directory
* Platform: Arduino with atmega328 e.g Uno or Nano 
* Install using Aruduino IDE 
* Requires: Array

## Python Library (TODO)

* Requirements: pyserial



